// =========================
// API FUNCTION (Встроенный запрос к бэкенду)
// =========================
async function createMood(entry) {
    try {
        // Запрос идет строго на твой порт бэкенда Go
        return await fetch("http://localhost:8080/api/moods", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(entry)
        });
    } catch (e) {
        console.error("Сетевая ошибка при вызове fetch:", e);
        return null;
    }
}

document.addEventListener("DOMContentLoaded", () => {

    // =========================
    // MOOD SELECT
    // =========================

    const moods = document.querySelectorAll(".mood");

    const moodScores = {
        "Плохо": 1,
        "Не очень": 2,
        "Нормально": 3,
        "Хорошо": 4,
        "Отлично": 5
    };

    let selectedMood = "Нормально";

    moods.forEach((mood) => {
        mood.addEventListener("click", () => {
            // убрать active у всех
            moods.forEach((m) => {
                m.classList.remove("active");
            });

            // добавить active текущему
            mood.classList.add("active");

            // сохранить выбранное настроение
            selectedMood = mood.querySelector("span").textContent.trim();

            console.log("Настроение:", selectedMood);
        });
    });

    // =========================
    // TAGS
    // =========================

    const tags = document.querySelectorAll(".tag");

    let selectedTags = [];

    tags.forEach((tag) => {
        // пропускаем кнопку добавления
        if (tag.classList.contains("add-tag-btn")) return;

        tag.addEventListener("click", () => {
            tag.classList.toggle("active");

            const tagText = tag.innerText.trim();

            if (selectedTags.includes(tagText)) {
                selectedTags = selectedTags.filter(t => t !== tagText);
            } else {
                selectedTags.push(tagText);
            }

            console.log("Теги:", selectedTags);
        });
    });

    // =========================
    // TAG MODAL
    // =========================

    const addTagBtn = document.querySelector(".add-tag-btn");
    const tagsBar = document.querySelector(".tags-bar");

    const tagModal = document.getElementById("tagModal");
    const tagInput = document.getElementById("tagInput");
    const saveTagBtn = document.getElementById("saveTagBtn");

    // открыть модалку
    if (addTagBtn) {
        addTagBtn.addEventListener("click", () => {
            tagModal.classList.add("show");
            tagInput.focus();
        });
    }

    // закрыть модалку
    function closeTagModal() {
        tagModal.classList.remove("show");
        tagInput.value = "";
    }

    // Сохранить тег по клику на кнопку в модалке
    if (saveTagBtn) {
        saveTagBtn.addEventListener("click", createTag);
    }

    // ENTER в модалке тегов
    if (tagInput) {
        tagInput.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                createTag();
            }
        });
    }

    // создание нового тега
    function createTag() {
        const newTag = tagInput.value.trim();

        if (!newTag) return;

        // проверка на дубликаты
        const existingTags = document.querySelectorAll(".tags-bar .tag");
        for (let tag of existingTags) {
            if (tag.textContent.toLowerCase() === newTag.toLowerCase()) {
                alert("Такой тег уже существует");
                return;
            }
        }

        // создать тег визуально
        const tag = document.createElement("span");
        tag.className = "tag";
        tag.textContent = newTag;

        // вставляем перед кнопкой добавления
        tagsBar.insertBefore(tag, addTagBtn);

        // обработчик клика для нового созданного тега
        tag.addEventListener("click", () => {
            tag.classList.toggle("active");

            if (selectedTags.includes(newTag)) {
                selectedTags = selectedTags.filter(t => t !== newTag);
            } else {
                selectedTags.push(newTag);
            }
            console.log("Теги:", selectedTags);
        });

        closeTagModal();
    }

    // закрытие по фону модалки
    if (tagModal) {
        tagModal.addEventListener("click", (e) => {
            if (e.target === tagModal) {
                closeTagModal();
            }
        });
    }

    // Сделаем функцию закрытия доступной для onclick из HTML на всякий случай
    window.closeTagModal = closeTagModal;

    // =========================
    // SAVE ENTRY (ОТПРАВКА НА БЭКЕНД)
    // =========================

    const saveBtn = document.querySelector(".save-btn");
    const textarea = document.querySelector(".note-box textarea") || document.querySelector("textarea");

    if (saveBtn) {
        saveBtn.addEventListener("click", saveEntry);
    }

    async function saveEntry() {
        const note = textarea.value.trim();

        // ИСПРАВЛЕНО: Объект полностью адаптирован под твой CreateMoodHandler в Go
        const entry = {
            mood: moodScores[selectedMood], // Заменили score на mood
            tags: selectedTags,             // Передаем как нормальный массив [], БЕЗ .join(",")
            note: note
        };

        console.log("Отправка пакета на бэкенд:", entry);

        try {
            saveBtn.textContent = "Сохранение...";
            saveBtn.disabled = true;

            // Вызываем функцию отправки запроса
            const response = await createMood(entry);

            // сервер недоступен
            if (!response) {
                throw new Error("Сервер бэкенда недоступен или выключен");
            }

            // ошибка сервера
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || "Внутренняя ошибка сервера");
            }

            // JSON ответ
            const result = await response.json();
            console.log("Ответ сервера:", result);

            // если пришла поддержка (мемы/шутки)
            if (result.support) {
                showSupportModal(result.support);
            } else {
                alert("Запись сохранена ✅");
            }

            // очистка формы
            resetForm();

        } catch (error) {
            console.error("Ошибка во время выполнения saveEntry:", error);
            alert("Ошибка соединения с сервером: " + error.message);
        } finally {
            saveBtn.textContent = "Сохранить";
            saveBtn.disabled = false;
        }
    }

    // =========================
    // RESET FORM
    // =========================

    function resetForm() {
        // очистить textarea
        if (textarea) textarea.value = "";

        // reset moods
        moods.forEach((m) => {
            m.classList.remove("active");
        });

        const normalMood = document.querySelector(".mood-normal");
        if (normalMood) normalMood.classList.add("active");

        selectedMood = "Нормально";

        // reset tags
        selectedTags = [];
        document.querySelectorAll(".tag.active").forEach((tag) => {
            tag.classList.remove("active");
        });
    }

    // =========================
    // SUPPORT MODAL
    // =========================

    function showSupportModal(support) {
        const modal = document.getElementById("supportModal");
        const data = document.getElementById("supportData");

        if (!modal || !data) return;
        data.innerHTML = "";

        // joke
        if (support.type === "joke") {
            const p = document.createElement("p");
            p.textContent = support.content;
            data.appendChild(p);
        }
        // image
        else if (support.type === "image") {
            const img = document.createElement("img");
            img.src = `http://localhost:8080${support.content}`;
            img.alt = "Support meme";
            data.appendChild(img);
        }

        modal.style.display = "flex";
    }

    function closeSupportModal() {
        const modal = document.getElementById("supportModal");
        if (modal) modal.style.display = "none";
    }

    // Делаем глобальной для HTML onclick="closeSupportModal()"
    window.closeSupportModal = closeSupportModal;
});